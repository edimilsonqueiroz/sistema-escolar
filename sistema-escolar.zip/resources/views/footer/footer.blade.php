    
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/jq-3.6.0/dt-1.12.1/b-2.2.3/cr-1.5.6/fh-3.2.3/r-2.3.0/sc-2.0.6/sl-1.4.0/datatables.min.js"></script>
    
    <script src="{{asset('js/script.js')}}"></script>
</body>
</html>