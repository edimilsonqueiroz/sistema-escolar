<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-main">
        <div class="mensagem">
            <?php if(session()->has('sucesso')): ?>
                <div class="alert"><?php echo e(session('sucesso')); ?></div>  
            <?php endif; ?>                     
        </div>
        <form method="post" class="form" action="<?php echo e(route('update-aluno', $aluno->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
        
            <div class="form-control">
                <input type="text" name="nome" value="<?php echo e($aluno->nome); ?>" placeholder="Nome completo" />
                <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <sapn class="invalid-feedback">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-control">
                <input type="date" value="<?php echo e($aluno->data_nascimento); ?>" name="data_nascimento" />
                <?php $__errorArgs = ['data_nascimento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <sapn class="invalid-feedback">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-control">
                <input type="text" name="cpf" value="<?php echo e($aluno->cpf); ?>" placeholder="CPF" />
                <?php $__errorArgs = ['cpf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <sapn class="invalid-feedback">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-control">
                <select name="sexo">
                    <?php if($aluno->sexo == 'Masculino'): ?>
                    <option selected value="Masculino">Masculino</option>
                    <option value="Feminino">Feminino</option>
                    <?php else: ?>
                        <option value="Masculino">Masculino</option>
                        <option selected value="Feminino">Feminino</option>
                    <?php endif; ?>
                </select>
                <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <sapn class="invalid-feedback">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-control">
                <input type="submit" value="Editar">
                <a href="<?php echo e(route('alunos')); ?>">Voltar</a>
            </div>
        </form>
</div>

<?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\laravel\sistema-escolar\resources\views/admin/alunos/editar.blade.php ENDPATH**/ ?>