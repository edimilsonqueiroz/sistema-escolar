
<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-main">
        <div class="main-card">
            <div class="card-info">
                <div class="card-body">
                    <?php echo e($matriculas); ?>

                </div>
                <div class="card-footer">
                    <a href="<?php echo e(route('matriculas')); ?>">Matriculas</a>
                </div>
            </div>
            <div class="card-info">
                <div class="card-body">
                    <?php echo e($turmas); ?>

                </div>
                <div class="card-footer">
                    <a href="<?php echo e(route('turmas')); ?>">Turmas</a>
                </div>
            </div>
            <div class="card-info">
                <div class="card-body">
                    <?php echo e($alunos); ?>

                </div>
                <div class="card-footer">
                    <a href="<?php echo e(route('alunos')); ?>">Alunos</a>
                </div>
            </div>
        </div>
    </div>
<?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\laravel\sistema-escolar\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>