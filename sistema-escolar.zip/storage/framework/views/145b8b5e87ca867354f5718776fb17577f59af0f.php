<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div style="padding-top:50px;" class="container-main">
    <form onSubmit=" return confirm('Deseja excluir os registros selecionados?')" method="post" action="<?php echo e(route('delete-turma')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <table id="listar" class="display" style="width:100%;">
            <thead>
                <tr>
                    <th>Selecionar</th>
                    <th>Nome da turma</th>
                    <th>Nome da escola</th>
                    <th>Série/Ano</th>
                    <th>Ano da turma</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $turmas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="text-align:center;">
                        <input type="checkbox" name="id[]" value="<?php echo e($turma->id); ?>"/>
                    </td>
                    <td><?php echo e($turma->nome); ?></td>
                    <td><?php echo e($turma->nome_escola); ?></td>
                    <td><?php echo e($turma->serie); ?></td>
                    <td><?php echo e($turma->ano); ?></td>
                    <td style="display:flex;">
                        <a class="btn-link" href="<?php echo e(route('edit-turma', $turma->id)); ?>">Editar</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="menu-table">
            <a href="<?php echo e(route('create-turma')); ?>" class="btn-link-add">Adicionar novo</a>
            <button type="submit" class="btn">Excluir registro selecionado</button>
        </div>
    </form>
</div>

<?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\laravel\sistema-escolar\resources\views/admin/turmas/listar.blade.php ENDPATH**/ ?>