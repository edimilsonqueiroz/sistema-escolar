<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-main">
        <div class="mensagem">
            <?php if(session()->has('sucesso')): ?>
                <div class="alert"><?php echo e(session('sucesso')); ?></div>  
            <?php endif; ?>                     
        </div>
        <form method="post" class="form" action="<?php echo e(route('store-turma')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-control">
                <input type="text" name="nome" placeholder="Nome da turma" value="<?php echo e(old('nome')); ?>" />
                <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <sapn class="invalid-feedback">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-control">
                <input type="text" placeholder="Nome da escola" name="nome_escola" value="<?php echo e(old('nome_escola')); ?>" />
                <?php $__errorArgs = ['nome_escola'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <sapn class="invalid-feedback">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-control">
                <input type="text" name="serie" placeholder="Série" value="<?php echo e(old('serie')); ?>"/>
                <?php $__errorArgs = ['serie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <sapn class="invalid-feedback">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-control">
                <input type="number" name="ano" placeholder="Ano da turma" value="<?php echo e(old('ano')); ?>"/>
                <?php $__errorArgs = ['ano'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <sapn class="invalid-feedback">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-control">
                <input type="submit" value="Cadastrar">
                <a href="<?php echo e(route('turmas')); ?>">Voltar</a>
            </div>
        </form>
</div>

<?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\laravel\sistema-escolar\resources\views/admin/turmas/cadastrar.blade.php ENDPATH**/ ?>