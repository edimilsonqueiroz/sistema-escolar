<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div style="padding-top:50px;" class="container-main">
    <div class="mensagem">
        <?php if(session()->has('sucesso')): ?>
            <div class="alert"><?php echo e(session('sucesso')); ?></div>  
        <?php endif; ?> 
        <?php if(session()->has('error')): ?>
            <div style="color:brown;"><?php echo e(session('error')); ?></div>  
        <?php endif; ?>
    </div>

    <form onSubmit="return confirm('Deseja excluir os registros selecionados?') " method="post" action="<?php echo e(route('delete-aluno')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <table id="listar" class="display" style="width:100%;">
            <thead>
                <tr>
                    <th>Selecionar</th>
                    <th>Nome</th>
                    <th>Data de Nascimento</th>
                    <th>CPF</th>
                    <th>Sexo</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="text-align:center;">
                        <input type="checkbox" name="id[]" value="<?php echo e($aluno->id); ?>"/>
                    </td>
                    <td><?php echo e($aluno->nome); ?></td>
                    <td><?php echo e(date('d/m/Y',strtotime($aluno->data_nascimento))); ?></td>
                    <td><?php echo e($aluno->cpf); ?></td>
                    <td><?php echo e($aluno->sexo); ?></td>
                    <td style="display:flex;">
                        <a class="btn-link" href="<?php echo e(route('edit-aluno',$aluno->id)); ?>">Editar</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="menu-table">
            <a href="<?php echo e(route('create-aluno')); ?>" class="btn-link-add">Adicionar novo</a>
            <button type="submit" class="btn">Excluir registro selecionado</button>
        </div>
    </form>
</div>

<?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\laravel\sistema-escolar\resources\views/admin/alunos/listar.blade.php ENDPATH**/ ?>