<?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div style="padding-top:50px;" class="container-main">
    <form onSubmit=" return confirm('Deseja excluir os registros selecionados?')" method="post" action="<?php echo e(route('delete-matricula')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <table id="listar" class="display" style="width:100%;">
            <thead>
                <tr>
                    <th>Selecionar</th>
                    <th>Ano</th>
                    <th>Aluno</th>
                    <th>Turma</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $matriculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matricula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="text-align:center;">
                        <input type="checkbox" name="matricula[]" value="<?php echo e($matricula->id); ?>"/>
                    </td>
                    <td><?php echo e($matricula->ano); ?></td>
                    <?php $__currentLoopData = $matricula->aluno()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($aluno->nome); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $matricula->turma()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($turma->serie); ?> - <?php echo e($turma->nome_escola); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td style="display:flex;">
                        <a class="btn-link" href="<?php echo e(route('edit-matricula', $matricula->id)); ?>">Editar</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="menu-table">
            <a href="<?php echo e(route('create-matricula')); ?>" class="btn-link-add">Adicionar novo</a>
            <button type="submit" class="btn">Excluir registro selecionado</button>
        </div>
    </form>
</div>

<?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\laravel\sistema-escolar\resources\views/admin/matriculas/listar.blade.php ENDPATH**/ ?>